<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/store_auth.php';

if (session_status() === PHP_SESSION_NONE) session_start();

$pdo = get_db();

$product_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$product_id) {
    header('Location: ' . SITE_URL . '/');
    exit;
}

$stmt = $pdo->prepare(
    "SELECT id, name, slug, description, price, stock_quantity, image, status
     FROM products
     WHERE id = ? AND status = 'active'"
);
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) {
    set_flash('warning', 'Product not found.');
    header('Location: ' . SITE_URL . '/');
    exit;
}

$out_of_stock = (int)$product['stock_quantity'] <= 0;
$low_stock    = !$out_of_stock && (int)$product['stock_quantity'] <= 5;
$img_url      = product_image_url($product['image']);
$csrf         = csrf_token();
$page_title   = $product['name'];
?>
<?php require_once __DIR__ . '/includes/header.php'; ?>

<script>
  const SITE_URL        = '<?= SITE_URL ?>';
  const CURRENCY_SYMBOL = '<?= SITE_CURRENCY_SYMBOL ?>';
</script>
<meta name="csrf-token" content="<?= e($csrf) ?>">

<div class="container">
  <!-- Breadcrumb -->
  <ol class="breadcrumb-sp" style="padding-top:28px;">
    <li><a href="<?= SITE_URL ?>/">Home</a></li>
    <li class="sep"><i class="bi bi-chevron-right"></i></li>
    <li><a href="<?= SITE_URL ?>/">Products</a></li>
    <li class="sep"><i class="bi bi-chevron-right"></i></li>
    <li><?= e($product['name']) ?></li>
  </ol>

  <!-- Product Detail -->
  <div class="product-detail-layout" style="padding-bottom:60px;">

    <!-- Image -->
    <div class="product-detail-img">
      <?php if ($product['image']): ?>
        <img src="<?= e($img_url) ?>" alt="<?= e($product['name']) ?>">
      <?php else: ?>
        <i class="bi bi-image no-img"></i>
      <?php endif; ?>
    </div>

    <!-- Info -->
    <div>
      <div class="product-detail-cat">Electronics &amp; Accessories</div>
      <h1 class="product-detail-name"><?= e($product['name']) ?></h1>
      <div class="product-detail-price"><?= format_money((float)$product['price']) ?></div>

      <?php if ($out_of_stock): ?>
        <span class="stock-indicator stock-out">
          <i class="bi bi-x-circle-fill"></i> Out of Stock
        </span>
      <?php elseif ($low_stock): ?>
        <span class="stock-indicator stock-low">
          <i class="bi bi-exclamation-triangle-fill"></i> Only <?= (int)$product['stock_quantity'] ?> left
        </span>
      <?php else: ?>
        <span class="stock-indicator stock-in">
          <i class="bi bi-check-circle-fill"></i> In Stock (<?= (int)$product['stock_quantity'] ?> available)
        </span>
      <?php endif; ?>

      <?php if ($product['description']): ?>
        <p class="product-detail-desc"><?= nl2br(e($product['description'])) ?></p>
      <?php endif; ?>

      <?php if (!$out_of_stock): ?>
        <!-- Add to cart -->
        <div class="add-to-cart-form">
          <div class="qty-group">
            <button class="qty-btn" type="button"
              data-qty-action="dec" data-qty-target="detail-qty">
              <i class="bi bi-dash"></i>
            </button>
            <input class="qty-num" type="number"
              id="detail-qty"
              data-qty-for="<?= $product['id'] ?>"
              value="1" min="1" max="<?= (int)$product['stock_quantity'] ?>">
            <button class="qty-btn" type="button"
              data-qty-action="inc" data-qty-target="detail-qty">
              <i class="bi bi-plus"></i>
            </button>
          </div>

          <button
            class="btn-sp btn-primary-sp btn-lg-sp"
            data-add-to-cart="<?= $product['id'] ?>"
          >
            <i class="bi bi-bag-plus-fill"></i> Add to Cart
          </button>
        </div>

        <div style="margin-top:14px;">
          <a href="<?= SITE_URL ?>/cart.php" class="btn-sp btn-ghost-sp btn-sm-sp">
            <i class="bi bi-bag"></i> View Cart
          </a>
        </div>

      <?php else: ?>
        <button class="btn-sp btn-ghost-sp btn-lg-sp" disabled>
          <i class="bi bi-x-circle"></i> Out of Stock
        </button>
      <?php endif; ?>

      <!-- Trust badges -->
      <div style="display:flex; gap:16px; margin-top:28px; padding-top:24px; border-top:1px solid var(--border); flex-wrap:wrap;">
        <?php foreach ([
          ['bi-shield-check', 'Secure Checkout'],
          ['bi-arrow-repeat', '7-day Returns'],
          ['bi-truck',        'Fast Delivery'],
        ] as [$icon, $label]): ?>
          <div style="display:flex; align-items:center; gap:6px; font-size:13px; color:var(--text-2);">
            <i class="bi <?= $icon ?>" style="color:var(--primary);"></i>
            <span><?= $label ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

  </div><!-- /.product-detail-layout -->
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>