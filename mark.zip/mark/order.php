<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/store_auth.php';

if (session_status() === PHP_SESSION_NONE) session_start();

require_login(SITE_URL . '/orders.php');

$pdo      = get_db();
$customer = current_customer();

$stmt = $pdo->prepare(
    "SELECT o.id, o.reference, o.total_amount, o.payment_status, o.order_status, o.created_at,
            COUNT(oi.id) AS item_count
     FROM orders o
     LEFT JOIN order_items oi ON oi.order_id = o.id
     WHERE o.customer_id = ?
     GROUP BY o.id
     ORDER BY o.created_at DESC"
);
$stmt->execute([$customer['id']]);
$orders = $stmt->fetchAll();

$page_title = 'My Orders';
$csrf       = csrf_token();
?>
<?php require_once __DIR__ . '/includes/header.php'; ?>

<script>
  const SITE_URL        = '<?= SITE_URL ?>';
  const CURRENCY_SYMBOL = '<?= SITE_CURRENCY_SYMBOL ?>';
</script>

<div class="container">
  <div class="page-head">
    <ol class="breadcrumb-sp">
      <li><a href="<?= SITE_URL ?>/">Home</a></li>
      <li class="sep"><i class="bi bi-chevron-right"></i></li>
      <li>My Orders</li>
    </ol>
    <h1><i class="bi bi-receipt" style="color:var(--primary)"></i> My Orders</h1>
  </div>

  <?php if (empty($orders)): ?>
    <div class="empty-state sp-card">
      <div class="empty-icon"><i class="bi bi-receipt"></i></div>
      <h3>No orders yet</h3>
      <p>You haven't placed any orders. Start shopping to see your orders here.</p>
      <a href="<?= SITE_URL ?>/" class="btn-sp btn-primary-sp">
        <i class="bi bi-grid"></i> Browse Products
      </a>
    </div>
  <?php else: ?>

    <!-- Summary stats -->
    <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:16px; margin-bottom:28px;">
      <?php
        $total_orders  = count($orders);
        $total_spend   = array_sum(array_column(
            array_filter($orders, fn($o) => $o['payment_status'] === 'paid'), 'total_amount'
        ));
        $pending_count = count(array_filter($orders, fn($o) => $o['payment_status'] === 'pending'));
      ?>
      <?php foreach ([
        ['bi-bag-check',   'Total Orders',  $total_orders,              null],
        ['bi-currency-exchange','Total Spent',format_money($total_spend),null],
        ['bi-clock-history','Pending',       $pending_count,             null],
      ] as [$icon, $label, $value, $_]): ?>
        <div class="sp-card" style="text-align:center; padding:18px;">
          <i class="bi <?= $icon ?>" style="font-size:22px; color:var(--primary); display:block; margin-bottom:6px;"></i>
          <div style="font-size:20px; font-weight:700; color:var(--gray-900);"><?= $value ?></div>
          <div style="font-size:12px; color:var(--text-2); margin-top:2px;"><?= $label ?></div>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- Orders list -->
    <?php foreach ($orders as $order): ?>
      <div class="order-card">
        <div class="order-card-head">
          <div>
            <div class="order-ref"><?= e($order['reference']) ?></div>
            <div class="order-date"><?= format_datetime($order['created_at']) ?></div>
          </div>
          <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap; justify-content:flex-end;">
            <?php
              $pay_class   = 'badge-' . $order['payment_status'];
              $order_class = 'badge-' . $order['order_status'];
            ?>
            <span class="sp-badge <?= $pay_class ?>">
              <?= ucfirst($order['payment_status']) ?>
            </span>
            <span class="sp-badge <?= $order_class ?>">
              <?= ucfirst($order['order_status']) ?>
            </span>
          </div>
        </div>

        <div class="order-card-body">
          <div class="order-items-preview">
            <i class="bi bi-box-seam" style="color:var(--text-2)"></i>
            <?= (int)$order['item_count'] ?> item<?= $order['item_count'] != 1 ? 's' : '' ?>
          </div>
          <div class="order-total"><?= format_money((float)$order['total_amount']) ?></div>
          <a href="<?= SITE_URL ?>/order-detail.php?id=<?= $order['id'] ?>"
             class="btn-sp btn-ghost-sp btn-sm-sp">
            <i class="bi bi-eye"></i> View Order
          </a>
        </div>
      </div>
    <?php endforeach; ?>

  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>