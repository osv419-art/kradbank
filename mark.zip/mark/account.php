<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/store_auth.php';

if (session_status() === PHP_SESSION_NONE) session_start();

require_login(SITE_URL . '/account.php');

$pdo      = get_db();
$customer = current_customer();

// Fetch full customer record
$stmt = $pdo->prepare("SELECT id, full_name, email, phone, created_at FROM customers WHERE id = ?");
$stmt->execute([$customer['id']]);
$profile = $stmt->fetch();

$errors   = [];
$success  = '';
$tab      = $_GET['tab'] ?? 'profile';

// ── Profile update ────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request.';
    } else {
        $full_name = trim($_POST['full_name'] ?? '');
        $phone     = trim($_POST['phone']     ?? '');

        if (strlen($full_name) < 2) {
            $errors[] = 'Full name must be at least 2 characters.';
        } elseif ($phone && !validate_phone($phone)) {
            $errors[] = 'Please enter a valid phone number.';
        } else {
            $stmt = $pdo->prepare("UPDATE customers SET full_name = ?, phone = ? WHERE id = ?");
            $stmt->execute([$full_name, $phone ?: null, $customer['id']]);
            // Update session
            $_SESSION['customer_name'] = $full_name;
            $profile['full_name'] = $full_name;
            $profile['phone']     = $phone;
            $success = 'Profile updated successfully.';
        }
    }
}

// ── Password change ───────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $tab = 'password';
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request.';
    } else {
        $current  = $_POST['current_password']  ?? '';
        $new_pw   = $_POST['new_password']       ?? '';
        $confirm  = $_POST['confirm_password']   ?? '';

        // Verify current password
        $stmt = $pdo->prepare("SELECT password FROM customers WHERE id = ?");
        $stmt->execute([$customer['id']]);
        $row = $stmt->fetch();

        if (!password_verify($current, $row['password'])) {
            $errors[] = 'Current password is incorrect.';
        } elseif (strlen($new_pw) < 8) {
            $errors[] = 'New password must be at least 8 characters.';
        } elseif ($new_pw !== $confirm) {
            $errors[] = 'New passwords do not match.';
        } else {
            $hash = password_hash($new_pw, PASSWORD_BCRYPT, ['cost' => 12]);
            $stmt = $pdo->prepare("UPDATE customers SET password = ? WHERE id = ?");
            $stmt->execute([$hash, $customer['id']]);
            $success = 'Password changed successfully.';
        }
    }
}

$page_title = 'Account Settings';
$csrf       = csrf_token();
?>
<?php require_once __DIR__ . '/includes/header.php'; ?>

<script>
  const SITE_URL        = '<?= SITE_URL ?>';
  const CURRENCY_SYMBOL = '<?= SITE_CURRENCY_SYMBOL ?>';
</script>

<div class="container">
  <div class="page-head">
    <ol class="breadcrumb-sp">
      <li><a href="<?= SITE_URL ?>/">Home</a></li>
      <li class="sep"><i class="bi bi-chevron-right"></i></li>
      <li>Account Settings</li>
    </ol>
    <h1><i class="bi bi-person-circle" style="color:var(--primary)"></i> Account Settings</h1>
  </div>

  <?php if (!empty($errors)): ?>
    <div class="alert alert-danger d-flex align-items-start gap-2 mb-3" role="alert">
      <i class="bi bi-x-circle-fill mt-1"></i>
      <div><?php foreach ($errors as $err): ?><div><?= e($err) ?></div><?php endforeach; ?></div>
    </div>
  <?php endif; ?>

  <?php if ($success): ?>
    <div class="alert alert-success d-flex align-items-center gap-2 mb-3" role="alert">
      <i class="bi bi-check-circle-fill"></i> <?= e($success) ?>
    </div>
  <?php endif; ?>

  <div style="display:grid; grid-template-columns:220px 1fr; gap:24px; align-items:start; padding-bottom:60px;">

    <!-- Sidebar nav -->
    <div class="sp-card" style="padding:12px;">
      <?php foreach ([
        ['profile',  'bi-person',       'Profile'],
        ['password', 'bi-key',          'Password'],
        ['orders',   'bi-receipt',      'My Orders'],
      ] as [$t, $icon, $label]): ?>
        <a href="<?= $t === 'orders' ? SITE_URL . '/orders.php' : '?tab=' . $t ?>"
           style="display:flex; align-items:center; gap:10px; padding:10px 12px; border-radius:var(--radius-sm); font-size:14px; font-weight:500; color:<?= $tab === $t ? 'var(--primary)' : 'var(--gray-700)' ?>; background:<?= $tab === $t ? 'var(--primary-light)' : 'transparent' ?>; text-decoration:none; margin-bottom:2px;">
          <i class="bi <?= $icon ?>"></i> <?= $label ?>
        </a>
      <?php endforeach; ?>
      <hr style="margin:10px 0; border-color:var(--border);">
      <a href="<?= SITE_URL ?>/logout.php"
         style="display:flex; align-items:center; gap:10px; padding:10px 12px; border-radius:var(--radius-sm); font-size:14px; font-weight:500; color:var(--danger); text-decoration:none;">
        <i class="bi bi-box-arrow-right"></i> Log Out
      </a>
    </div>

    <!-- Tab content -->
    <div>
      <?php if ($tab === 'profile'): ?>
        <div class="sp-card">
          <div class="sp-card-head"><h3>Profile Information</h3></div>
          <form method="POST">
            <?= csrf_field() ?>
            <input type="hidden" name="update_profile" value="1">
            <div class="form-row">
              <div class="sp-form-group">
                <label class="sp-label req" for="full_name">Full Name</label>
                <input class="sp-input" type="text" id="full_name" name="full_name"
                  value="<?= e($profile['full_name']) ?>" required>
              </div>
              <div class="sp-form-group">
                <label class="sp-label" for="phone">Phone Number</label>
                <input class="sp-input" type="tel" id="phone" name="phone"
                  value="<?= e($profile['phone'] ?? '') ?>" placeholder="+234 800 000 0000">
              </div>
            </div>
            <div class="sp-form-group">
              <label class="sp-label">Email Address</label>
              <input class="sp-input" type="email" value="<?= e($profile['email']) ?>" disabled
                style="background:var(--gray-50); color:var(--text-2);">
              <span class="sp-hint">Email cannot be changed.</span>
            </div>
            <div class="sp-form-group">
              <label class="sp-label">Member Since</label>
              <input class="sp-input" type="text" value="<?= format_date($profile['created_at']) ?>" disabled
                style="background:var(--gray-50); color:var(--text-2);">
            </div>
            <button type="submit" class="btn-sp btn-primary-sp">
              <i class="bi bi-check2"></i> Save Changes
            </button>
          </form>
        </div>

      <?php elseif ($tab === 'password'): ?>
        <div class="sp-card">
          <div class="sp-card-head"><h3>Change Password</h3></div>
          <form method="POST" style="max-width:420px;">
            <?= csrf_field() ?>
            <input type="hidden" name="change_password" value="1">
            <div class="sp-form-group">
              <label class="sp-label req" for="current_password">Current Password</label>
              <input class="sp-input" type="password" id="current_password" name="current_password" required>
            </div>
            <div class="sp-form-group">
              <label class="sp-label req" for="new_password">New Password</label>
              <input class="sp-input" type="password" id="new_password" name="new_password"
                placeholder="At least 8 characters" required>
            </div>
            <div class="sp-form-group">
              <label class="sp-label req" for="confirm_password">Confirm New Password</label>
              <input class="sp-input" type="password" id="confirm_password" name="confirm_password" required>
            </div>
            <button type="submit" class="btn-sp btn-primary-sp">
              <i class="bi bi-lock"></i> Update Password
            </button>
          </form>
        </div>
      <?php endif; ?>
    </div>

  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>