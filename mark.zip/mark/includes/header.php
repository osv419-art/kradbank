<?php
/**
 * Store header — included at the top of every customer-facing page.
 * Expects $page_title to be set before inclusion.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$_cart_count = cart_count();
$_customer   = current_customer();
$_page_title = isset($page_title) ? e($page_title) . ' — ' . SITE_NAME : SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $_page_title ?></title>
  <meta name="description" content="ShopPro — Premium products delivered fast.">

  <!-- Bootstrap 5 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <!-- Store CSS -->
 <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<!-- ─── Top Navigation ─────────────────────────────────────────────────── -->
<nav class="store-nav" id="storeNav">
  <div class="nav-inner">

    <!-- Logo -->
    <a href="<?= SITE_URL ?>/" class="nav-logo">
      Shop<span>Pro</span>
    </a>

    <!-- Desktop links -->
    <ul class="nav-links d-none d-md-flex">
      <li><a href="<?= SITE_URL ?>/" class="<?= basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : '' ?>">
        <i class="bi bi-house"></i> Home
      </a></li>
      <li><a href="<?= SITE_URL ?>/" class="">
        <i class="bi bi-grid"></i> Products
      </a></li>
    </ul>

    <!-- Actions -->
    <div class="nav-actions">
      <!-- Cart -->
      <a href="<?= SITE_URL ?>/cart.php" class="nav-cart-btn">
        <i class="bi bi-bag"></i>
        <span class="d-none d-sm-inline">Cart</span>
        <?php if ($_cart_count > 0): ?>
          <span class="cart-badge"><?= $_cart_count ?></span>
        <?php endif; ?>
      </a>

      <!-- Account -->
      <?php if ($_customer): ?>
        <div class="dropdown">
          <button class="nav-account-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="bi bi-person-circle"></i>
            <span class="d-none d-sm-inline"><?= e(explode(' ', $_customer['full_name'])[0]) ?></span>
          </button>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="<?= SITE_URL ?>/orders.php">
              <i class="bi bi-receipt me-2"></i>My Orders
            </a></li>
            <li><a class="dropdown-item" href="<?= SITE_URL ?>/account.php">
              <i class="bi bi-gear me-2"></i>Account Settings
            </a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="<?= SITE_URL ?>/logout.php">
              <i class="bi bi-box-arrow-right me-2"></i>Log Out
            </a></li>
          </ul>
        </div>
      <?php else: ?>
        <a href="<?= SITE_URL ?>/login.php" class="nav-account-btn">
          <i class="bi bi-person"></i>
          <span class="d-none d-sm-inline">Sign In</span>
        </a>
      <?php endif; ?>

      <!-- Mobile hamburger -->
      <button class="nav-mobile-toggle d-md-none" id="mobileMenuToggle" aria-label="Menu">
        <i class="bi bi-list" style="font-size:22px"></i>
      </button>
    </div>
  </div>

  <!-- Mobile menu -->
  <div class="mobile-menu d-md-none" id="mobileMenu">
    <a href="<?= SITE_URL ?>/">
      <i class="bi bi-house"></i> Home
    </a>
    <a href="<?= SITE_URL ?>/">
      <i class="bi bi-grid"></i> Products
    </a>
    <a href="<?= SITE_URL ?>/cart.php">
      <i class="bi bi-bag"></i> Cart
      <?php if ($_cart_count > 0): ?>
        <span class="cart-badge ms-1"><?= $_cart_count ?></span>
      <?php endif; ?>
    </a>
    <?php if ($_customer): ?>
      <a href="<?= SITE_URL ?>/orders.php"><i class="bi bi-receipt"></i> My Orders</a>
      <a href="<?= SITE_URL ?>/logout.php" class="text-danger"><i class="bi bi-box-arrow-right"></i> Log Out</a>
    <?php else: ?>
      <a href="<?= SITE_URL ?>/login.php"><i class="bi bi-person"></i> Sign In</a>
      <a href="<?= SITE_URL ?>/register.php"><i class="bi bi-person-plus"></i> Create Account</a>
    <?php endif; ?>
  </div>
</nav>

<!-- ─── Flash Messages ─────────────────────────────────────────────────── -->
<?php $__flash = get_flash(); if ($__flash): ?>
<div class="flash-wrapper">
  <div class="container">
    <div class="alert alert-<?= e($__flash['type']) ?> d-flex align-items-center gap-2" role="alert">
      <?php
        $icons = ['success'=>'bi-check-circle-fill','danger'=>'bi-x-circle-fill','warning'=>'bi-exclamation-triangle-fill','info'=>'bi-info-circle-fill'];
        $icon  = $icons[$__flash['type']] ?? 'bi-info-circle-fill';
      ?>
      <i class="bi <?= $icon ?>"></i>
      <span><?= e($__flash['message']) ?></span>
      <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Toast container -->
<div class="toast-container" id="toastContainer"></div>

<main class="main-content">