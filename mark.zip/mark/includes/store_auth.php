<?php
/**
 * ShopPro — Customer authentication helpers
 */

function customer_session_start(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function is_logged_in(): bool
{
    customer_session_start();
    return !empty($_SESSION['customer_id']);
}

function current_customer(): ?array
{
    customer_session_start();
    if (empty($_SESSION['customer_id'])) {
        return null;
    }
    return [
        'id'        => (int) $_SESSION['customer_id'],
        'full_name' => $_SESSION['customer_name'] ?? '',
        'email'     => $_SESSION['customer_email'] ?? '',
    ];
}

function require_login(string $redirect_back = ''): void
{
    if (!is_logged_in()) {
        $redirect = $redirect_back ?: SITE_URL . '/login.php';
        set_flash('info', 'Please log in to continue.');
        header('Location: ' . SITE_URL . '/login.php?redirect=' . urlencode($redirect_back ?: $_SERVER['REQUEST_URI']));
        exit;
    }
}

function login_customer(array $customer): void
{
    customer_session_start();
    session_regenerate_id(true);  // Prevent session fixation
    $_SESSION['customer_id']    = $customer['id'];
    $_SESSION['customer_name']  = $customer['full_name'];
    $_SESSION['customer_email'] = $customer['email'];
}

function logout_customer(): void
{
    customer_session_start();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(), '',
            time() - 42000,
            $params['path'], $params['domain'],
            $params['secure'], $params['httponly']
        );
    }
    session_destroy();
}

function attempt_login(string $email, string $password, PDO $pdo): array
{
    $identifier = strtolower(trim($email));

    // Rate limit check
    if (is_rate_limited($identifier, $pdo)) {
        return [
            'ok'    => false,
            'error' => 'Too many failed login attempts. Please try again in ' . LOGIN_LOCKOUT_MINS . ' minutes.',
        ];
    }

    $stmt = $pdo->prepare(
        "SELECT id, full_name, email, password, status FROM customers WHERE email = ?"
    );
    $stmt->execute([$identifier]);
    $customer = $stmt->fetch();

    if (!$customer || !password_verify($password, $customer['password'])) {
        record_login_attempt($identifier, $pdo);
        return ['ok' => false, 'error' => 'Invalid email or password.'];
    }

    if ($customer['status'] !== 'active') {
        return ['ok' => false, 'error' => 'Your account has been suspended. Contact support.'];
    }

    clear_login_attempts($identifier, $pdo);
    login_customer($customer);

    return ['ok' => true, 'customer' => $customer];
}

function register_customer(array $data, PDO $pdo): array
{
    $full_name = trim($data['full_name'] ?? '');
    $email     = strtolower(trim($data['email'] ?? ''));
    $phone     = trim($data['phone'] ?? '');
    $password  = $data['password'] ?? '';
    $confirm   = $data['confirm_password'] ?? '';

    // Validate
    if (strlen($full_name) < 2 || strlen($full_name) > 100) {
        return ['ok' => false, 'error' => 'Full name must be between 2 and 100 characters.'];
    }
    if (!validate_email($email)) {
        return ['ok' => false, 'error' => 'Please enter a valid email address.'];
    }
    if ($phone && !validate_phone($phone)) {
        return ['ok' => false, 'error' => 'Please enter a valid phone number.'];
    }
    if (strlen($password) < 8) {
        return ['ok' => false, 'error' => 'Password must be at least 8 characters.'];
    }
    if ($password !== $confirm) {
        return ['ok' => false, 'error' => 'Passwords do not match.'];
    }

    // Check duplicate email
    $stmt = $pdo->prepare("SELECT id FROM customers WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        return ['ok' => false, 'error' => 'An account with that email already exists.'];
    }

    $hashed = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

    $stmt = $pdo->prepare(
        "INSERT INTO customers (full_name, email, phone, password) VALUES (?, ?, ?, ?)"
    );
    $stmt->execute([$full_name, $email, $phone ?: null, $hashed]);
    $id = (int) $pdo->lastInsertId();

    $customer = [
        'id'        => $id,
        'full_name' => $full_name,
        'email'     => $email,
    ];

    login_customer($customer);

    return ['ok' => true, 'customer' => $customer];
}