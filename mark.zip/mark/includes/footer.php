<?php
/**
 * Store footer — included at the bottom of every customer-facing page.
 */
?>
</main><!-- /.main-content -->

<!-- ─── Footer ────────────────────────────────────────────────────────── -->
<footer class="store-footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="footer-logo">Shop<span>Pro</span></div>
        <p class="footer-tagline">Premium products delivered fast.<br>Quality you can trust.</p>
      </div>
      <div class="footer-links-group">
        <h5>Shop</h5>
        <ul>
          <li><a href="<?= SITE_URL ?>/">All Products</a></li>
          <li><a href="<?= SITE_URL ?>/cart.php">Cart</a></li>
          <li><a href="<?= SITE_URL ?>/checkout.php">Checkout</a></li>
        </ul>
      </div>
      <div class="footer-links-group">
        <h5>Account</h5>
        <ul>
          <?php if (is_logged_in()): ?>
            <li><a href="<?= SITE_URL ?>/orders.php">My Orders</a></li>
            <li><a href="<?= SITE_URL ?>/account.php">Settings</a></li>
            <li><a href="<?= SITE_URL ?>/logout.php">Log Out</a></li>
          <?php else: ?>
            <li><a href="<?= SITE_URL ?>/login.php">Sign In</a></li>
            <li><a href="<?= SITE_URL ?>/register.php">Create Account</a></li>
          <?php endif; ?>
        </ul>
      </div>
      <div class="footer-links-group">
        <h5>Support</h5>
        <ul>
          <li><a href="mailto:hello@shoppro.com">Contact Us</a></li>
        </ul>
      </div>
    </div>

    <div class="footer-bottom">
      <span>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. All rights reserved.</span>
      <span class="footer-secure">
        <i class="bi bi-shield-check"></i> Secured by Squad
      </span>
    </div>
  </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Store JS -->
<script src="<?= SITE_URL ?>/assets/js/store.js"></script>
</body>
</html>