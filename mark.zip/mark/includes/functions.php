<?php
/**
 * ShopPro — Shared helper functions
 */

// ─── CSRF ─────────────────────────────────────────────────────────────────────

function csrf_token(): string
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token(), ENT_QUOTES) . '">';
}

function verify_csrf(string $token): bool
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    return !empty($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $token);
}

// ─── Output escaping ─────────────────────────────────────────────────────────

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

// ─── Formatting ──────────────────────────────────────────────────────────────

function format_money(float $amount): string
{
    return SITE_CURRENCY_SYMBOL . number_format($amount, 2);
}

function format_date(string $datetime): string
{
    return date('M j, Y', strtotime($datetime));
}

function format_datetime(string $datetime): string
{
    return date('M j, Y g:i A', strtotime($datetime));
}

// ─── Flash messages ───────────────────────────────────────────────────────────

function set_flash(string $type, string $message): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash(): ?array
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function render_flash(): void
{
    $flash = get_flash();
    if (!$flash) return;

    $icon_map = [
        'success' => 'check-circle',
        'danger'  => 'x-circle',
        'warning' => 'alert-triangle',
        'info'    => 'info',
    ];
    $icon = $icon_map[$flash['type']] ?? 'info';

    printf(
        '<div class="alert alert-%s" role="alert">
            <i data-lucide="%s"></i>
            <span>%s</span>
        </div>',
        e($flash['type']),
        e($icon),
        e($flash['message'])
    );
}

// ─── Cart ─────────────────────────────────────────────────────────────────────

function cart_init(): void
{
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
}

function cart_get(): array
{
    cart_init();
    return $_SESSION['cart'];
}

function cart_count(): int
{
    $total = 0;
    foreach (cart_get() as $item) {
        $total += (int) $item['quantity'];
    }
    return $total;
}

function cart_total(): float
{
    $total = 0.0;
    foreach (cart_get() as $item) {
        $total += (float) $item['price'] * (int) $item['quantity'];
    }
    return $total;
}

function cart_add(int $product_id, int $quantity, PDO $pdo): array
{
    cart_init();

    // Validate product
    $stmt = $pdo->prepare("SELECT id, name, price, stock_quantity, status FROM products WHERE id = ? AND status = 'active'");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();

    if (!$product) {
        return ['ok' => false, 'error' => 'Product not found.'];
    }

    $existing_qty = isset($_SESSION['cart'][$product_id])
        ? (int) $_SESSION['cart'][$product_id]['quantity']
        : 0;

    $new_qty = $existing_qty + $quantity;

    if ($new_qty > $product['stock_quantity']) {
        return ['ok' => false, 'error' => 'Not enough stock available.'];
    }

    $_SESSION['cart'][$product_id] = [
        'product_id' => $product_id,
        'name'       => $product['name'],
        'price'      => (float) $product['price'],
        'quantity'   => $new_qty,
    ];

    return ['ok' => true];
}

function cart_update(int $product_id, int $quantity, PDO $pdo): array
{
    cart_init();

    if ($quantity <= 0) {
        unset($_SESSION['cart'][$product_id]);
        return ['ok' => true];
    }

    $stmt = $pdo->prepare("SELECT stock_quantity FROM products WHERE id = ? AND status = 'active'");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();

    if (!$product) {
        return ['ok' => false, 'error' => 'Product not found.'];
    }
    if ($quantity > $product['stock_quantity']) {
        return ['ok' => false, 'error' => 'Not enough stock available.'];
    }

    $_SESSION['cart'][$product_id]['quantity'] = $quantity;
    return ['ok' => true];
}

function cart_remove(int $product_id): void
{
    cart_init();
    unset($_SESSION['cart'][$product_id]);
}

function cart_clear(): void
{
    $_SESSION['cart'] = [];
}

// ─── Order reference ──────────────────────────────────────────────────────────

function generate_order_reference(): string
{
    return 'SP-' . strtoupper(date('Ymd')) . '-' . strtoupper(bin2hex(random_bytes(4)));
}

// ─── Rate limiting ────────────────────────────────────────────────────────────

function is_rate_limited(string $identifier, PDO $pdo): bool
{
    $window = date('Y-m-d H:i:s', time() - (LOGIN_LOCKOUT_MINS * 60));

    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM login_attempts
         WHERE identifier = ? AND attempted_at >= ?"
    );
    $stmt->execute([$identifier, $window]);
    $count = (int) $stmt->fetchColumn();

    return $count >= LOGIN_MAX_ATTEMPTS;
}

function record_login_attempt(string $identifier, PDO $pdo): void
{
    $stmt = $pdo->prepare(
        "INSERT INTO login_attempts (identifier, ip_address) VALUES (?, ?)"
    );
    $stmt->execute([$identifier, $_SERVER['REMOTE_ADDR'] ?? '']);

    // Prune old attempts
    $pdo->exec("DELETE FROM login_attempts WHERE attempted_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)");
}

function clear_login_attempts(string $identifier, PDO $pdo): void
{
    $stmt = $pdo->prepare("DELETE FROM login_attempts WHERE identifier = ?");
    $stmt->execute([$identifier]);
}

// ─── Squad Payment API ────────────────────────────────────────────────────────

/**
 * Initiate a payment with Squad.
 * Returns ['ok' => true, 'checkout_url' => '...'] or ['ok' => false, 'error' => '...']
 */
function squad_initiate_payment(array $params): array
{
    $url = SQUAD_API_URL . '/transaction/initiate';

    $body = json_encode([
        'email'           => $params['email'],
        'amount'          => (int) round($params['amount'] * 100),  // kobo
        'initiate_type'   => 'redirect',
        'currency'        => 'NGN',
        'transaction_ref' => $params['reference'],
        'callback_url'    => $params['callback_url'],
        'pass_charge'     => false,
    ]);

    $response = squad_api_request('POST', $url, $body);

    if (!$response['ok']) {
        return $response;
    }

    $data = $response['data'];

    $checkout_url = $data['data']['checkout_url']
        ?? $data['data']['auth_url']
        ?? null;

    if (!$checkout_url) {
        return ['ok' => false, 'error' => 'Could not retrieve checkout URL from Squad.'];
    }

    return ['ok' => true, 'checkout_url' => $checkout_url];
}

/**
 * Verify a transaction with Squad server-side.
 * Returns ['ok' => true, 'data' => [...]] or ['ok' => false, 'error' => '...']
 */
function squad_verify_transaction(string $reference): array
{
    $url = SQUAD_API_URL . '/transaction/verify/' . urlencode($reference);
    return squad_api_request('GET', $url, null);
}

/**
 * Internal Squad API request helper.
 */
function squad_api_request(string $method, string $url, ?string $body): array
{
    $ch = curl_init($url);

    $headers = [
        'Authorization: Bearer ' . SQUAD_SECRET_KEY,
        'Content-Type: application/json',
        'Accept: application/json',
    ];

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }

    $raw      = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_err  = curl_error($ch);
    curl_close($ch);

    if ($curl_err) {
        error_log('Squad cURL error: ' . $curl_err);
        return ['ok' => false, 'error' => 'Payment gateway connection error.'];
    }

    $decoded = json_decode($raw, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log('Squad invalid JSON response: ' . $raw);
        return ['ok' => false, 'error' => 'Invalid response from payment gateway.'];
    }

    if ($http_code < 200 || $http_code >= 300) {
        $msg = $decoded['message'] ?? 'Payment gateway error.';
        return ['ok' => false, 'error' => $msg];
    }

    return ['ok' => true, 'data' => $decoded];
}

// ─── Image helpers ────────────────────────────────────────────────────────────

function product_image_url(?string $filename): string
{
    if ($filename && file_exists(UPLOAD_PATH . $filename)) {
        return UPLOAD_URL . $filename;
    }
    return SITE_URL . '/assets/images/no-image.svg';
}

function upload_product_image(array $file): array
{
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'error' => 'File upload failed.'];
    }
    if ($file['size'] > MAX_UPLOAD_BYTES) {
        return ['ok' => false, 'error' => 'Image must be under 2 MB.'];
    }

    $allowed_mime = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    $finfo        = new finfo(FILEINFO_MIME_TYPE);
    $mime         = $finfo->file($file['tmp_name']);

    if (!in_array($mime, $allowed_mime, true)) {
        return ['ok' => false, 'error' => 'Only JPEG, PNG, WebP, or GIF images are allowed.'];
    }

    $ext      = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = bin2hex(random_bytes(12)) . '.' . strtolower($ext);
    $dest     = UPLOAD_PATH . $filename;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        return ['ok' => false, 'error' => 'Could not save image.'];
    }

    return ['ok' => true, 'filename' => $filename];
}

// ─── Input validation ─────────────────────────────────────────────────────────

function validate_email(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validate_phone(string $phone): bool
{
    return preg_match('/^\+?[0-9\s\-]{7,20}$/', $phone) === 1;
}