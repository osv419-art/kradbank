<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/store_auth.php';

if (session_status() === PHP_SESSION_NONE) session_start();

// Must be logged in to checkout
require_login(SITE_URL . '/checkout.php');

$pdo = get_db();

// Refresh cart from DB
$cart_items = cart_get();
if (empty($cart_items)) {
    set_flash('info', 'Your cart is empty.');
    header('Location: ' . SITE_URL . '/cart.php');
    exit;
}

// Validate stock and recalculate server-side totals
$ids  = array_keys($cart_items);
$ph   = implode(',', array_fill(0, count($ids), '?'));
$stmt = $pdo->prepare(
    "SELECT id, name, price, stock_quantity FROM products WHERE id IN ($ph) AND status = 'active'"
);
$stmt->execute($ids);
$db_products = [];
foreach ($stmt->fetchAll() as $row) {
    $db_products[$row['id']] = $row;
}

$errors   = [];
$verified = [];     // Cart items we trust (from DB)

foreach ($cart_items as $pid => $item) {
    if (!isset($db_products[$pid])) {
        $errors[] = '"' . e($item['name']) . '" is no longer available.';
        cart_remove($pid);
        continue;
    }
    $db  = $db_products[$pid];
    $qty = (int)$item['quantity'];
    if ($qty > (int)$db['stock_quantity']) {
        $errors[] = '"' . e($db['name']) . '": only ' . $db['stock_quantity'] . ' left in stock.';
        $qty = (int)$db['stock_quantity'];
        if ($qty <= 0) {
            cart_remove($pid);
            continue;
        }
        cart_update($pid, $qty, $pdo);
    }
    $verified[$pid] = [
        'product_id' => (int)$pid,
        'name'       => $db['name'],
        'price'      => (float)$db['price'],
        'quantity'   => $qty,
        'subtotal'   => (float)$db['price'] * $qty,
    ];
}

if (empty($verified)) {
    set_flash('danger', 'Your cart is empty after stock validation.');
    header('Location: ' . SITE_URL . '/cart.php');
    exit;
}

$subtotal = array_sum(array_column($verified, 'subtotal'));
$total    = $subtotal;   // No extra fees

$customer = current_customer();

// ── Handle checkout POST ──────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request. Please try again.';
    }

    $shipping_name    = trim($_POST['shipping_name']    ?? '');
    $shipping_email   = strtolower(trim($_POST['shipping_email'] ?? ''));
    $shipping_phone   = trim($_POST['shipping_phone']   ?? '');
    $shipping_address = trim($_POST['shipping_address'] ?? '');
    $notes            = trim($_POST['notes']            ?? '');

    // Validate
    if (empty($errors)) {
        if (strlen($shipping_name) < 2)         $errors[] = 'Full name is required.';
        if (!validate_email($shipping_email))    $errors[] = 'Valid email address is required.';
        if (!validate_phone($shipping_phone))    $errors[] = 'Valid phone number is required.';
        if (strlen($shipping_address) < 5)       $errors[] = 'Delivery address is required.';
    }

    if (empty($errors)) {
        // Begin DB transaction
        $pdo->beginTransaction();

        try {
            $reference = generate_order_reference();

            // Insert order
            $stmt = $pdo->prepare(
                "INSERT INTO orders
                 (customer_id, reference, subtotal, total_amount,
                  shipping_name, shipping_email, shipping_phone, shipping_address, notes)
                 VALUES (?,?,?,?,?,?,?,?,?)"
            );
            $stmt->execute([
                $customer['id'],
                $reference,
                $subtotal,
                $total,
                $shipping_name,
                $shipping_email,
                $shipping_phone,
                $shipping_address,
                $notes ?: null,
            ]);
            $order_id = (int)$pdo->lastInsertId();

            // Insert order items (use DB prices — never trust browser)
            $stmt = $pdo->prepare(
                "INSERT INTO order_items (order_id, product_id, product_name, quantity, price, subtotal)
                 VALUES (?,?,?,?,?,?)"
            );
            foreach ($verified as $item) {
                $stmt->execute([
                    $order_id,
                    $item['product_id'],
                    $item['name'],
                    $item['quantity'],
                    $item['price'],
                    $item['subtotal'],
                ]);
            }

            // Insert pending payment record
            $stmt = $pdo->prepare(
                "INSERT INTO payments (order_id, transaction_reference, amount, status)
                 VALUES (?,?,?,'pending')"
            );
            $stmt->execute([$order_id, $reference, $total]);

            $pdo->commit();

            // Initiate Squad payment (outside transaction — network call)
            $squad_result = squad_initiate_payment([
                'email'        => $shipping_email,
                'amount'       => $total,
                'reference'    => $reference,
                'callback_url' => SITE_URL . '/payment/callback.php',
            ]);

            if (!$squad_result['ok']) {
                // Log the error; customer can retry
                error_log('Squad initiate error for order ' . $order_id . ': ' . $squad_result['error']);
                $errors[] = 'Payment gateway error: ' . $squad_result['error'] . ' Please try again.';
            } else {
                // Success — redirect customer to Squad checkout
                header('Location: ' . $squad_result['checkout_url']);
                exit;
            }

        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log('Checkout DB error: ' . $e->getMessage());
            $errors[] = 'Order could not be placed. Please try again.';
        }
    }
}

$page_title = 'Checkout';
$csrf       = csrf_token();
?>
<?php require_once __DIR__ . '/includes/header.php'; ?>

<script>
  const SITE_URL        = '<?= SITE_URL ?>';
  const CURRENCY_SYMBOL = '<?= SITE_CURRENCY_SYMBOL ?>';
</script>

<div class="container">
  <div class="page-head">
    <ol class="breadcrumb-sp">
      <li><a href="<?= SITE_URL ?>/">Home</a></li>
      <li class="sep"><i class="bi bi-chevron-right"></i></li>
      <li><a href="<?= SITE_URL ?>/cart.php">Cart</a></li>
      <li class="sep"><i class="bi bi-chevron-right"></i></li>
      <li>Checkout</li>
    </ol>
    <h1><i class="bi bi-lock-fill" style="color:var(--primary)"></i> Secure Checkout</h1>
  </div>

  <?php if (!empty($errors)): ?>
    <div class="alert alert-danger d-flex align-items-start gap-2 mb-4" role="alert">
      <i class="bi bi-x-circle-fill mt-1"></i>
      <div>
        <?php foreach ($errors as $err): ?>
          <div><?= e($err) ?></div>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endif; ?>

  <form method="POST" id="checkoutForm">
    <?= csrf_field() ?>

    <div class="checkout-layout">
      <!-- ── Left column: Delivery info ──────────────────────────────────── -->
      <div>
        <!-- Delivery details -->
        <div class="checkout-section">
          <div class="checkout-section-title">
            <i class="bi bi-person-fill"></i> Delivery Information
          </div>

          <div class="form-row">
            <div class="sp-form-group">
              <label class="sp-label req" for="shipping_name">Full Name</label>
              <input class="sp-input" type="text" id="shipping_name" name="shipping_name"
                value="<?= e($_POST['shipping_name'] ?? $customer['full_name']) ?>"
                placeholder="John Doe" required>
            </div>
            <div class="sp-form-group">
              <label class="sp-label req" for="shipping_phone">Phone Number</label>
              <input class="sp-input" type="tel" id="shipping_phone" name="shipping_phone"
                value="<?= e($_POST['shipping_phone'] ?? '') ?>"
                placeholder="+234 800 000 0000" required>
            </div>
          </div>

          <div class="sp-form-group">
            <label class="sp-label req" for="shipping_email">Email Address</label>
            <input class="sp-input" type="email" id="shipping_email" name="shipping_email"
              value="<?= e($_POST['shipping_email'] ?? $customer['email']) ?>"
              placeholder="you@example.com" required>
            <span class="sp-hint">Payment receipt and order updates will be sent here.</span>
          </div>

          <div class="sp-form-group">
            <label class="sp-label req" for="shipping_address">Delivery Address</label>
            <textarea class="sp-textarea" id="shipping_address" name="shipping_address"
              placeholder="Street, city, state" required><?= e($_POST['shipping_address'] ?? '') ?></textarea>
          </div>

          <div class="sp-form-group" style="margin-bottom:0">
            <label class="sp-label" for="notes">Order Notes <span style="font-weight:400;color:var(--text-3)">(optional)</span></label>
            <textarea class="sp-textarea" id="notes" name="notes"
              style="min-height:70px"
              placeholder="Any special instructions..."><?= e($_POST['notes'] ?? '') ?></textarea>
          </div>
        </div>

        <!-- Payment method info -->
        <div class="checkout-section">
          <div class="checkout-section-title">
            <i class="bi bi-credit-card-fill"></i> Payment Method
          </div>
          <div style="display:flex; align-items:center; gap:14px; padding:14px 18px; background:var(--primary-light); border:1.5px solid var(--primary-border); border-radius:var(--radius-sm);">
            <i class="bi bi-shield-check" style="font-size:28px; color:var(--primary);"></i>
            <div>
              <div style="font-weight:600; font-size:15px; color:var(--gray-900);">Squad by GTBank</div>
              <div style="font-size:13px; color:var(--text-2);">Pay securely with card, bank transfer, or USSD. You will be redirected to Squad to complete payment.</div>
            </div>
          </div>
        </div>
      </div>

      <!-- ── Right column: Order summary ─────────────────────────────────── -->
      <div>
        <div class="summary-card">
          <div class="summary-title">Order Summary</div>

          <!-- Items list -->
          <?php foreach ($verified as $item): ?>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; font-size:14px;">
              <div>
                <div style="font-weight:500; color:var(--gray-900);"><?= e($item['name']) ?></div>
                <div style="font-size:12px; color:var(--text-2);">
                  <?= format_money($item['price']) ?> &times; <?= $item['quantity'] ?>
                </div>
              </div>
              <div style="font-weight:600;"><?= format_money($item['subtotal']) ?></div>
            </div>
          <?php endforeach; ?>

          <hr class="summary-divider">

          <div class="summary-line">
            <span class="lbl">Subtotal</span>
            <span class="val"><?= format_money($subtotal) ?></span>
          </div>
          <div class="summary-line">
            <span class="lbl">Shipping</span>
            <span class="val" style="color:var(--success);">Free</span>
          </div>

          <hr class="summary-divider">

          <div class="summary-total">
            <span class="lbl">Total</span>
            <span class="val"><?= format_money($total) ?></span>
          </div>

          <div style="margin-top:20px;">
            <button type="submit" class="btn-sp btn-primary-sp btn-lg-sp btn-block-sp">
              <i class="bi bi-lock-fill"></i>
              Pay <?= format_money($total) ?> Securely
            </button>
          </div>

          <div style="text-align:center; margin-top:14px; font-size:12px; color:var(--text-3); display:flex; align-items:center; justify-content:center; gap:5px;">
            <i class="bi bi-shield-check" style="color:var(--success);"></i>
            256-bit SSL encrypted payment
          </div>
        </div>

        <div style="margin-top:12px; text-align:center;">
          <a href="<?= SITE_URL ?>/cart.php" style="font-size:13px; color:var(--text-2);">
            <i class="bi bi-arrow-left"></i> Back to cart
          </a>
        </div>
      </div>

    </div><!-- /.checkout-layout -->
  </form>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>