<?php
/**
 * ShopPro Configuration
 * Update these values before deployment.
 */

// ─── Database ────────────────────────────────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_NAME', 'store');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// ─── Site ────────────────────────────────────────────────────────────────────
// No trailing slash
define('SITE_URL', 'http://localhost/store');
define('SITE_NAME', 'ShopPro');
define('SITE_CURRENCY', 'NGN');
define('SITE_CURRENCY_SYMBOL', '₦');

// ─── Squad Payment Gateway ───────────────────────────────────────────────────
// Get keys from https://dashboard.squadco.com
define('SQUAD_PUBLIC_KEY',  'SQPUBK_TEST_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX');
define('SQUAD_SECRET_KEY',  'SKSB_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX');
define('SQUAD_SANDBOX',     true);   // Set false for live
define('SQUAD_API_URL',     SQUAD_SANDBOX
    ? 'https://sandbox-api-d.squadco.com'
    : 'https://api-d.squadco.com');

// ─── File Uploads ────────────────────────────────────────────────────────────
define('UPLOAD_PATH',       dirname(__DIR__) . '/uploads/products/');
define('UPLOAD_URL',        SITE_URL . '/uploads/products/');
define('MAX_UPLOAD_BYTES',  2 * 1024 * 1024);  // 2 MB

// ─── Session ─────────────────────────────────────────────────────────────────
define('SESSION_LIFETIME',  3600);  // 1 hour

// ─── Rate Limiting ───────────────────────────────────────────────────────────
define('LOGIN_MAX_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_MINS', 15);

// ─── Error Handling ──────────────────────────────────────────────────────────
// In production set display_errors to 0
ini_set('display_errors', 1);
ini_set('log_errors',     1);
error_reporting(E_ALL);

// ─── Secure session settings ─────────────────────────────────────────────────
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.gc_maxlifetime', SESSION_LIFETIME);