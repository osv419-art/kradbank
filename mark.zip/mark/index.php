<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/store_auth.php';

if (session_status() === PHP_SESSION_NONE) session_start();

$pdo = get_db();

// ── Fetch active products ─────────────────────────────────────────────────────
$stmt = $pdo->query(
    "SELECT id, name, slug, description, price, stock_quantity, image
     FROM products
     WHERE status = 'active'
     ORDER BY created_at DESC"
);
$products = $stmt->fetchAll();

$page_title = 'Home';
$csrf       = csrf_token();
?>
<?php require_once __DIR__ . '/includes/header.php'; ?>

<!-- Inline config for JS -->
<script>
  const SITE_URL        = '<?= SITE_URL ?>';
  const CURRENCY_SYMBOL = '<?= SITE_CURRENCY_SYMBOL ?>';
</script>
<meta name="csrf-token" content="<?= e($csrf) ?>">

<!-- ─── Hero ─────────────────────────────────────────────────────────────── -->
<section class="hero">
  <div class="hero-content">
    <div class="hero-eyebrow">
      <i class="bi bi-stars"></i> New arrivals every week
    </div>
    <h1>Premium Products<br>Delivered Fast</h1>
    <p>Discover our curated collection of high-quality electronics and accessories. Every item is quality-tested and backed by our customer promise.</p>
    <div class="hero-actions">
      <a href="#products" class="btn-hero-primary">
        <i class="bi bi-grid-3x3-gap-fill"></i> Browse Products
      </a>
      <?php if (!is_logged_in()): ?>
        <a href="<?= SITE_URL ?>/register.php" class="btn-hero-ghost">
          Create Account
        </a>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- ─── Trust Bar ─────────────────────────────────────────────────────────── -->
<div style="background:#fff; border-bottom:1px solid var(--border); padding:14px 0;">
  <div class="container">
    <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:12px; text-align:center;">
      <?php foreach ([
        ['bi-shield-check',   'Secure Payments',   'Powered by Squad'],
        ['bi-arrow-repeat',   'Easy Returns',      '7-day return policy'],
        ['bi-truck',          'Fast Delivery',     'Nationwide shipping'],
        ['bi-headset',        '24/7 Support',      'We\'re always here'],
      ] as [$icon, $title, $sub]): ?>
      <div style="display:flex; align-items:center; justify-content:center; gap:10px; padding:8px;">
        <i class="bi <?= $icon ?>" style="font-size:20px; color:var(--primary);"></i>
        <div style="text-align:left;">
          <div style="font-size:13px; font-weight:600; color:var(--gray-900);"><?= $title ?></div>
          <div style="font-size:12px; color:var(--text-2);"><?= $sub ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- ─── Products Section ──────────────────────────────────────────────────── -->
<section class="section" id="products">
  <div class="container">
    <div class="section-head">
      <div class="section-head-left">
        <h2>All Products</h2>
        <p><?= count($products) ?> item<?= count($products) !== 1 ? 's' : '' ?> available</p>
      </div>
    </div>

    <?php if (empty($products)): ?>
      <div class="empty-state">
        <div class="empty-icon"><i class="bi bi-box-seam"></i></div>
        <h3>No products yet</h3>
        <p>Check back soon — new items are added regularly.</p>
      </div>
    <?php else: ?>
      <div class="product-grid">
        <?php foreach ($products as $p): ?>
          <?php
            $out_of_stock = $p['stock_quantity'] <= 0;
            $low_stock    = !$out_of_stock && $p['stock_quantity'] <= 5;
            $img_url      = product_image_url($p['image']);
          ?>
          <div class="product-card">
            <a href="<?= SITE_URL ?>/product.php?id=<?= $p['id'] ?>" style="text-decoration:none;">
              <div class="product-thumb">
                <?php if ($p['image']): ?>
                  <img src="<?= e($img_url) ?>" alt="<?= e($p['name']) ?>" loading="lazy">
                <?php else: ?>
                  <div class="product-no-img">
                    <i class="bi bi-image"></i>
                    <span>No image</span>
                  </div>
                <?php endif; ?>

                <?php if ($out_of_stock): ?>
                  <span class="product-pill pill-out">Out of stock</span>
                <?php elseif ($low_stock): ?>
                  <span class="product-pill pill-low">Only <?= $p['stock_quantity'] ?> left</span>
                <?php endif; ?>
              </div>
            </a>

            <div class="product-body">
              <a href="<?= SITE_URL ?>/product.php?id=<?= $p['id'] ?>" style="text-decoration:none;">
                <div class="product-name"><?= e($p['name']) ?></div>
                <div class="product-desc"><?= e($p['description']) ?></div>
              </a>

              <div class="product-meta">
                <div class="product-price"><?= format_money((float)$p['price']) ?></div>
                <?php if (!$out_of_stock): ?>
                  <div class="product-stock-label"><?= $p['stock_quantity'] ?> in stock</div>
                <?php endif; ?>
              </div>

              <div class="product-foot">
                <?php if ($out_of_stock): ?>
                  <button class="btn-sp btn-ghost-sp btn-block-sp" disabled>
                    <i class="bi bi-x-circle"></i> Out of Stock
                  </button>
                <?php else: ?>
                  <button
                    class="btn-sp btn-primary-sp btn-block-sp"
                    data-add-to-cart="<?= $p['id'] ?>"
                  >
                    <i class="bi bi-bag-plus"></i> Add to Cart
                  </button>
                  <a href="<?= SITE_URL ?>/product.php?id=<?= $p['id'] ?>"
                     class="btn-sp btn-ghost-sp btn-icon-sp" title="View details">
                    <i class="bi bi-eye"></i>
                  </a>
                <?php endif; ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>