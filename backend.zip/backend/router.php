<?php
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = rawurldecode($uri);

if ($uri === '/' || $uri === '') {
    require __DIR__ . '/api.php';
    return;
}

$path = __DIR__ . $uri;
if (is_file($path)) {
    return false;
}

require __DIR__ . '/api.php';
