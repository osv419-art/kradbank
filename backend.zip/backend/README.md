# PHP Backend for Bank App

This backend provides a minimal REST API for the Flutter bank app.

## Start server

From the backend folder:

```bash
cd backend
php -S localhost:8000 router.php
```

Then use endpoints like:

- http://localhost:8000/auth
- http://localhost:8000/account
- http://localhost:8000/transactions
- http://localhost:8000/transfers
- http://localhost:8000/investments
- http://localhost:8000/budgets

> If you are running the Flutter app in Android Studio emulator, use http://10.0.2.2:8000 instead of localhost.

## Demo login

```json
{
  "email": "ava@bankapp.com",
  "password": "password123"
}
```

## Auth token

The backend accepts a bearer token:

```http
Authorization: Bearer demo_token_123
```
