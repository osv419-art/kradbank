<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

const JWT_SECRET = 'bank_app_secret_2026!';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

function loadStore(): array {
    $storeFile = __DIR__ . '/data/store.json';
    if (!file_exists($storeFile)) {
        http_response_code(500);
        echo json_encode(['error' => 'Store file not found.']);
        exit;
    }

    $raw = file_get_contents($storeFile);
    $data = json_decode($raw, true);

    if (!is_array($data)) {
        http_response_code(500);
        echo json_encode(['error' => 'Invalid store data.']);
        exit;
    }

    return $data;
}

function saveStore(array $data): void {
    $storeFile = __DIR__ . '/data/store.json';
    file_put_contents(
        $storeFile,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
    );
}

function jsonResponse(array $payload, int $status = 200): void {
    http_response_code($status);
    echo json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function base64UrlEncode(string $value): string {
    return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
}

function base64UrlDecode(string $value): string {
    $padding = strlen($value) % 4;
    if ($padding > 0) {
        $value .= str_repeat('=', 4 - $padding);
    }
    return base64_decode(strtr($value, '-_', '+/'));
}

function createJwt(array $payload): string {
    $header = ['alg' => 'HS256', 'typ' => 'JWT'];
    $encodedHeader = base64UrlEncode(json_encode($header));
    $encodedPayload = base64UrlEncode(json_encode($payload));
    $signature = hash_hmac('sha256', $encodedHeader . '.' . $encodedPayload, JWT_SECRET, true);
    return $encodedHeader . '.' . $encodedPayload . '.' . base64UrlEncode($signature);
}

function verifyJwt(string $token): ?array {
    try {
        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            return null;
        }

        [$header, $payload, $signature] = $parts;
        $expected = base64UrlEncode(hash_hmac('sha256', $header . '.' . $payload, JWT_SECRET, true));

        if (!hash_equals($expected, $signature)) {
            return null;
        }

        $data = json_decode(base64UrlDecode($payload), true);
        if (!is_array($data)) {
            return null;
        }

        if (($data['exp'] ?? 0) < time()) {
            return null;
        }

        return $data;
    } catch (Throwable $e) {
        return null;
    }
}

function getBearerToken(): ?string {
    $headers = getallheaders();
    $auth = $headers['Authorization'] ?? $headers['authorization'] ?? null;

    if (!$auth || !str_starts_with($auth, 'Bearer ')) {
        return null;
    }

    return trim(substr($auth, 7));
}

function requireAuth(): array {
    $token = getBearerToken();
    if (!$token) {
        jsonResponse(['error' => 'Unauthorized'], 401);
    }

    $claims = verifyJwt($token);
    if (!$claims) {
        jsonResponse(['error' => 'Invalid or expired token'], 401);
    }

    return $claims;
}

function parseRequestSegments(): array {
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '/';
    $segments = array_values(array_filter(explode('/', trim($path, '/')), fn($segment) => $segment !== ''));

    if (count($segments) > 0 && $segments[0] === 'backend') {
        array_shift($segments);
    }

    return $segments;
}

function resolvePassword(string $password, string $storedHash): bool {
    if (password_get_info($storedHash)['algo'] !== 0) {
        return password_verify($password, $storedHash);
    }

    return $password === $storedHash;
}

$data = loadStore();
$segments = parseRequestSegments();
$route = $segments[0] ?? null;
$method = $_SERVER['REQUEST_METHOD'];

if ($route === 'health' && $method === 'GET') {
    jsonResponse(['status' => 'ok', 'service' => 'bank-app-api']);
}

if ($route === 'auth' && $method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $email = trim((string) ($input['email'] ?? ''));
    $password = (string) ($input['password'] ?? '');

    $storedUser = $data['user'] ?? null;
    if (!$storedUser || $email !== (string) ($storedUser['email'] ?? '') || !resolvePassword($password, (string) ($storedUser['password'] ?? ''))) {
        jsonResponse(['error' => 'Invalid credentials'], 401);
    }

    $token = createJwt([
        'sub' => (string) $storedUser['id'],
        'email' => $storedUser['email'],
        'iat' => time(),
        'exp' => time() + 3600 * 24,
    ]);

    jsonResponse([
        'id' => $storedUser['id'],
        'name' => $storedUser['name'],
        'email' => $storedUser['email'],
        'token' => $token,
    ], 200);
}

if ($route === 'account' && $method === 'GET') {
    requireAuth();
    jsonResponse($data['account']);
}

if ($route === 'transactions' && $method === 'GET') {
    requireAuth();
    $limit = isset($_GET['limit']) ? max(1, (int) $_GET['limit']) : 50;
    jsonResponse(array_slice($data['transactions'] ?? [], 0, $limit));
}

if ($route === 'transfers' && $method === 'POST') {
    requireAuth();
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $recipientAccount = trim((string) ($input['recipientAccount'] ?? ''));
    $amount = (float) ($input['amount'] ?? 0);
    $description = trim((string) ($input['description'] ?? 'Transfer'));

    if ($recipientAccount === '' || $amount <= 0) {
        jsonResponse(['error' => 'Invalid transfer data'], 400);
    }

    if (($data['account']['balance'] ?? 0) < $amount) {
        jsonResponse(['error' => 'Insufficient balance'], 400);
    }

    $data['account']['balance'] = (float) ($data['account']['balance'] ?? 0) - $amount;
    $data['transactions'][] = [
        'id' => 'txn_' . uniqid(),
        'type' => 'transfer',
        'amount' => $amount,
        'description' => $description ?: 'Transfer',
        'date' => gmdate('c'),
        'status' => 'completed',
        'recipientName' => 'Recipient ' . $recipientAccount,
        'recipientAccount' => $recipientAccount,
    ];

    saveStore($data);
    jsonResponse(['success' => true]);
}

if ($route === 'bills' && $method === 'GET') {
    requireAuth();
    jsonResponse([
        [
            'id' => 'bill_1',
            'provider' => 'Electric Company',
            'amount' => 120.5,
            'dueDate' => gmdate('c', strtotime('+5 days')),
            'status' => 'pending',
        ],
        [
            'id' => 'bill_2',
            'provider' => 'Internet Provider',
            'amount' => 59.99,
            'dueDate' => gmdate('c', strtotime('+10 days')),
            'status' => 'pending',
        ],
        [
            'id' => 'bill_3',
            'provider' => 'Water Utility',
            'amount' => 45.0,
            'dueDate' => gmdate('c', strtotime('-2 days')),
            'status' => 'overdue',
        ],
    ]);
}

if ($route === 'bills' && $method === 'POST' && ($segments[1] ?? null) === 'pay') {
    requireAuth();
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $billId = (string) ($input['billId'] ?? '');
    $amount = (float) ($input['amount'] ?? 0);

    if ($billId === '' || $amount <= 0) {
        jsonResponse(['error' => 'Invalid payment data'], 400);
    }

    if (($data['account']['balance'] ?? 0) < $amount) {
        jsonResponse(['error' => 'Insufficient balance'], 400);
    }

    $data['account']['balance'] = (float) ($data['account']['balance'] ?? 0) - $amount;
    $data['transactions'][] = [
        'id' => 'txn_' . uniqid(),
        'type' => 'bill_payment',
        'amount' => $amount,
        'description' => 'Bill payment: ' . $billId,
        'date' => gmdate('c'),
        'status' => 'completed',
        'recipientName' => 'Bill Provider',
        'recipientAccount' => $billId,
    ];

    saveStore($data);
    jsonResponse(['success' => true]);
}

if ($route === 'investments' && $method === 'GET') {
    requireAuth();
    jsonResponse($data['investments'] ?? []);
}

if ($route === 'budgets' && $method === 'GET') {
    requireAuth();
    jsonResponse($data['budgets'] ?? []);
}

if ($route === 'budgets' && $method === 'POST') {
    requireAuth();
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $category = trim((string) ($input['category'] ?? ''));
    $limit = (float) ($input['limit'] ?? 0);
    $startDate = (string) ($input['startDate'] ?? gmdate('c'));
    $endDate = (string) ($input['endDate'] ?? gmdate('c', strtotime('+30 days')));

    if ($category === '' || $limit <= 0) {
        jsonResponse(['error' => 'Invalid budget data'], 400);
    }

    $data['budgets'][] = [
        'id' => 'bud_' . uniqid(),
        'category' => $category,
        'limit' => $limit,
        'spent' => 0,
        'startDate' => $startDate,
        'endDate' => $endDate,
    ];

    saveStore($data);
    jsonResponse(['success' => true]);
}

jsonResponse(['error' => 'Route not found'], 404);
